@javax.xml.bind.annotation.XmlSchema(namespace = "http://dao.visa.ssii2/")
package ssii2.visa.dao;
